#include <stdio.h>
int close_stream (FILE *stream);
